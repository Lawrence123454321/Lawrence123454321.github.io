import keys


print(keys.input2str(int(input('len?'))))