#pragma once
#include "../Config.hpp"

#include <SDL.h>

namespace casioemu
{
	struct ColourInfo
	{
		int r, g, b;
	};
}
