#pragma once

namespace casioemu
{
	enum HardwareId
	{
		HW_ES_PLUS = 3,
		HW_CLASSWIZ = 4,
		HW_CLASSWIZ_II = 5
	};
}

