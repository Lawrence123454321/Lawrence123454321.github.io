#pragma once

namespace casioemu
{
	enum EventCode
	{
		CE_FRAME_REQUEST,
		CE_EMU_STOPPED
	};
}

