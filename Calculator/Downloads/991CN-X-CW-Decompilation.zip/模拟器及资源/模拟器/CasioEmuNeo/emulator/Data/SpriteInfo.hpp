#pragma once
#include "../Config.hpp"

#include <SDL.h>

namespace casioemu
{
	struct SpriteInfo
	{
		SDL_Rect src, dest;
	};
}

