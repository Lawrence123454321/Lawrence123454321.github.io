#pragma once


class Terminal{
public:  
    Terminal();

    void show();

};