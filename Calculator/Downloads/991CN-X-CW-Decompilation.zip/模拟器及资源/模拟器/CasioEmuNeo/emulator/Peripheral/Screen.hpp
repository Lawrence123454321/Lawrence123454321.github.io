#pragma once
#include "../Config.hpp"

#include "Peripheral.hpp"

namespace casioemu
{
	Peripheral *CreateScreen(Emulator& emulator);
}

