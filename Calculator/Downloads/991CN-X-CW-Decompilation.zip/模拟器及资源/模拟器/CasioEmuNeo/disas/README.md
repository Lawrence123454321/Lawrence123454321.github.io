My disassembler.

For Windows users: Make sure that the line ending in `nX-U8*.txt`, `example.cpp` and `help.txt` is correct.
