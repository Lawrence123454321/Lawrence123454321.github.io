#pragma once

std::string tohex(int, int);
std::string tobin(int, int);
