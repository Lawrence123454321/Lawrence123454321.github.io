# ui介绍
--> [返回目录](../README.md)

## 监视窗口
![](wc1.png)

## 内存窗口
![](wc2.png)

## ROP注入窗口
![](wc3.png)

## 调试窗口
![](image.png)