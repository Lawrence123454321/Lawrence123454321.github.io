# 模拟器及资源

## 真机模拟器

「模拟器」文件夹中包含了两款模拟器，其中，CasioEmuX 对 CWii 适配较好，CasioEmuNeo 有 ROP 注入等附加功能。

希望有大佬进行合并。

## 真机 ROM

收录了 fx-991 CN X (Ver C) 与 fx-991 CN CW (Ver A) 的真机 ROM。

## 字符表

收录了 Casio fx-991 CN X 的单、双字节字符表，提供 PDF 版和 Excel 版。

后续会更新 991CN CW 的。

## 字体

收录了 Casio ClassWiz X & CW 的按键字体与屏幕显示字体。

按键字体由卡西欧官方提供，也可以前去 [ClassWizX](https://edu.casio.com/cn/forteachers/er/fontsets/) 与 [ClassWizCW](https://edu.casio.com/forteachers/er/fontsets/index.php) 下载到。屏幕显示字体由吧友制作。