# 反编译结果
这里有991CN X ROM 的汇编版本 (991CN X.txt) 和C语言源代码版本 (991CN X.c)
