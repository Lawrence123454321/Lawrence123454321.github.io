# nX-U8 处理器
这里存储了一些nX-U8 CPU 的补充资料
* 如果你刚开始学习汇编语言，不熟悉汇编指令，请阅读[Assembly Language](指令集/Assembly%20Language.pdf) (请下载后阅读);
* 如果你想特定地了解nX-U8处理器的架构，请阅读[nX-U8 Core Instruction Manual](指令集/nX-U8%20Core%20Instruction%20Manual.pdf) (请下载后阅读).
